function BasketCtrl($scope) {
  $scope.description = 'Single ticket';
  $scope.cost = 8;
  $scope.qty = 1;
}